export const aladhanUrl = 'https://api.aladhan.com';
export const prayZoneUrl = 'https://api.pray.zone';

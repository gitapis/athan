import { countries } from './../helpers/strings';

export default function() {
  return countries;
}

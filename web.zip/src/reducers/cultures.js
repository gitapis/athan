import { cultures } from './../helpers/strings';

export default function() {
  return cultures;
}

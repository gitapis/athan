export const ErrorType = 'Error';
export const LoadingType = 'Loading';
export const SuccessType = 'Success';
